from django.contrib import admin
from .models import TelegramAlertPlugin

admin.site.register(TelegramAlertPlugin)