from setuptools import setup, find_packages

setup(
    name="sc_telegram_plugin",
    version="4.0",
    description="sitechecker telegram plugin",
    author="Sahil Rajpal",
    author_email="sahilrajpal85@gmail.com",
    packages=find_packages(),
)
